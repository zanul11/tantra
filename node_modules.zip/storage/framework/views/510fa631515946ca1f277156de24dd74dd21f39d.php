<html lang="id">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=21cm, initial-scale=1">
    <meta name="description" content="Sistem Informasi Akademik Universitas Mataram">
    <meta name="author" content="Universitas Mataram">
    <title>LAPORAN DOKUMEN SIP/SIPA</title>
    <link rel="stylesheet" href="<?php echo e(asset('cetak/b.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('cetak/f.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('cetak/style.css')); ?>">

    <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('assets/img/logo.png')); ?>" sizes="16x16">
    <link rel="apple-touch-icon" href="<?php echo e(asset('assets/img/logo.png')); ?>">
    <link rel="apple-touch-icon-precomposed" href="<?php echo e(asset('assets/img/logo.png')); ?>">

    <style>
        @media  print {
            body {
                -webkit-print-color-adjust: exact;
            }
        }
    </style>
</head>

<body class="view mahasiswa halaman" onload="cetak()">
    <div class="container-fluid cetak krs">
        <div class="row">

            <center>
                <b style="font-size: 14px;">PROGRES IZIN SUMUR BOR</b><br>
            </center>
            <br>
            <table class="table table-hover table-bordered">

                <tBody>

                    <tr>
                        <td style="text-align: center;" width="3%"><b style=" font-size: 8px;">No</b></td>
                        <td style="text-align: center;"><b style="font-size: 8px;">SUMUR BOR</b></td>
                        <?php $__currentLoopData = $progres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td style="text-align: center;"><b style="font-size: 8px;"><?php echo e($pg->progres); ?></b></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <td style="text-align: center;"><b style="font-size: 8px;">Nomor</b></td>
                        <td style="text-align: center;"><b style="font-size: 8px;">Berlaku Izin</b></td>
                        <td style="text-align: center;"><b style="font-size: 8px;">Berakhir Izin</b></td>
                        <td style="text-align: center;"><b style="font-size: 8px;">Izin yg diberikan (l/dt)</b></td>
                    </tr>

                    <?php $__currentLoopData = $data_dok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="text-align: center; font-size: 8px;" width="3%"><?php echo e($loop->iteration); ?></td>
                        <td style="text-align: center; font-size: 8px;"><?php echo e($dt->sumber); ?></td>
                        <?php $__currentLoopData = $dt->log; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $image = asset('assets/img/check-symbol.png/');
                        ?>
                        <td style="text-align: center; font-size: 8px; background-color:<?php echo e(($log->status==1) ? '' : 'yellow!important'); ?>" width="8%"><?php echo ($log->status==1)?'<img src="'.$image.'" width=" 22" />':''; ?> <?php echo e((isset($log->ket))?'('.$log->ket.')':''); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <td style="text-align: center; font-size: 8px; background-color:<?php echo e(($dt->nomor) ? '' : 'yellow!important'); ?>" width="15%"><?php echo e($dt->nomor??''); ?></td>
                        <td style="text-align: center; font-size: 8px; background-color:<?php echo e(($dt->tgl_berlaku) ? '' : 'yellow!important'); ?>" width="5%"><?php echo e(($dt->tgl_berlaku) ? date('d-m-Y', strtotime($dt->tgl_berlaku)) : ''); ?></td>
                        <td style="text-align: center; font-size: 8px; background-color:<?php echo e(($dt->tgl_berakhir) ? '' : 'yellow!important'); ?>" width="5%"><?php echo e(($dt->tgl_berakhir) ? date('d-m-Y', strtotime($dt->tgl_berakhir)) : ''); ?></td>
                        <td style="text-align: center; font-size: 8px; background-color:<?php echo e(($dt->izin) ? '' : 'yellow!important'); ?>" width="4%"><?php echo e(($dt->izin) ? $dt->izin : ''); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tBody>
            </table>

        </div>
        <br>
    </div>

    <script type="text/javascript">
        function cetak() {
            window.print();
        };
    </script>


</body>

</html><?php /**PATH D:\laragon\www\sipro\resources\views/pages/dokumen/cetak.blade.php ENDPATH**/ ?>