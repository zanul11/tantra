<html lang="id">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=21cm, initial-scale=1">
    <meta name="description" content="Sistem Informasi Akademik Universitas Mataram">
    <meta name="author" content="Universitas Mataram">
    <title>LAPORAN BACA WATER METER</title>
    <link rel="stylesheet" href="<?php echo e(asset('cetak/b.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('cetak/f.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('cetak/style.css')); ?>">

    <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('assets/img/logo.png')); ?>" sizes="16x16">
    <link rel="apple-touch-icon" href="<?php echo e(asset('assets/img/logo.png')); ?>">
    <link rel="apple-touch-icon-precomposed" href="<?php echo e(asset('assets/img/logo.png')); ?>">

    <style>

    </style>
</head>

<body class="view mahasiswa halaman" onload="cetak()">
    <div class="container-fluid cetak krs">
        <div class="row">

            <center>
                <b style="font-size: 14px;">DATA SISA CHLOR/DESINFECTAN</b><br>
            </center>
            <br>
            <table class="table table-hover table-bordered">

                <tBody>
                    <tr>
                        <td colspan="<?php echo e(count($data_laporan[0]->data)+3); ?>" style="text-align: center;"> <b style="font-size: 13px;"><?php echo e($sumber->nama); ?></b></td>
                    </tr>
                    <tr>
                        <td style="text-align: center;   vertical-align: middle;" width="20%" rowspan="2" align="center"><b style=" font-size: 12px;">Tanggal</b></td>
                        <td style="text-align: center;" colspan="<?php echo e(count($data_laporan[0]->data)); ?>"><b style="font-size: 12px;">Catatan Sisa Chlor</b></td>
                        <td style="text-align: center;   vertical-align: middle;" rowspan="2"><b style="font-size: 12px;">Keterangan</b></td>
                    </tr>
                    <tr>
                        <?php $__currentLoopData = $data_laporan[0]->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td style="text-align: center;"><b style="font-size: 12px;"><?php echo e($dt->bak_nama); ?> / <?php echo e(substr($dt->jam_nama,0,5)); ?></b></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                    <?php $__currentLoopData = $data_laporan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="text-align: center;"><?php echo e(date('d-m-Y', strtotime($dt->tgl))); ?></td>
                        <?php $__currentLoopData = $dt->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td style="text-align: center; "><?php echo e($stan->sisa); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <td style="text-align: center;">-</td>
                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tBody>
            </table>
            <div class="pull-left ttd">
                QR-PRD/01-01
                <br> <br>Diperiksa<br>
                <br>Asisten Manajer & Reservoir & Perpompaan,
                <br><br>
                <?php echo '<img src="data:image/png;base64,' . DNS2D::getBarcodePNG('Diperiksa oleh : Asisten Manajer & Reservoir & Perpompaan', 'QRCODE', 1.5,1.5) . '" alt="barcode" />'; ?>

                <br><br>
                <span class="nama">Supriyanto</span>
            </div>


            <div class="pull-right ttd">
                <br> <br><?php echo e($sumber->kecamatan); ?>, <?php echo e(\Carbon\Carbon::now()->translatedFormat('d F Y')); ?><br>
                <br>Pelaksana,
                <br><br>
                <?php echo '<img src="data:image/png;base64,' . DNS2D::getBarcodePNG('Diterbitkan oleh : '.Auth::user()->nama, 'QRCODE', 1.5,1.5) . '" alt="barcode" />'; ?>

                <br><br>
                <span class="nama"><?php echo e($sumber->penjaga->nama); ?></span>
            </div>
        </div>
        <br>
    </div>

    <script type="text/javascript">
        function cetak() {
            window.print();
        };
    </script>


</body>

</html><?php /**PATH D:\laragon\www\sipro\resources\views/pages/chlor/cetak.blade.php ENDPATH**/ ?>