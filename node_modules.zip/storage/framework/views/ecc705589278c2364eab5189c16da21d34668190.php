

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('plugins_styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="content" class="content">
    <!-- begin breadcrumb -->
    <ol class="breadcrumb pull-right">
        <li class="breadcrumb-item"><a href="<?php echo e(url('/dashboard')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item"><a>Data Master</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(url('/sumber')); ?>"><?php echo e(($action=='add')?$jenis:$sumber->jenis); ?></a></li>
        <li class="breadcrumb-item"><a>Detail Data</a></li>
    </ol>
    <!-- end breadcrumb -->
    <!-- begin page-header -->
    <h1 class="page-header text-danger font-weight-bold"><span class="text-custom">DETAIL DATA</span> <?php echo e(($action=='add')?$jenis:$sumber->jenis); ?></h1>

    <div class="panel panel-inverse">
        <!-- begin panel-heading -->
        <div class="panel-heading ui-sortable-handle">
            <h4 class="panel-title">Data</h4>
        </div>
        <form method="POST" action="<?php echo e(($action=='add')?'/sumber':'/sumber/'.$sumber->id); ?>">
            <?php echo csrf_field(); ?>
            <?php if($action!='add'): ?>
            <?php echo method_field('PUT'); ?>
            <?php endif; ?>
            <div class="panel-body" style="max-height: 20;">
                <div class="row width-full">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="control-label">Nama Sumber</label>
                            <div class="input-group">
                                <input type="text" class="form-control" style="display: block;" value="<?php echo e(old('nama',$sumber->nama??'')); ?>" name="nama" placeholder="Nama Sumber..." required disabled>
                            </div>
                        </div>
                    </div>
                    <?php if($action=='add'): ?>
                    <input type="hidden" name="jenis" value=" <?php echo e($jenis); ?>">
                    <?php endif; ?>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label class="control-label">Alat Ukur</label>
                            <div class="input-group">

                                <input type="text" class="form-control" style="display: block;" value="<?php echo e(old('nama',$sumber->alat_ukur??'')); ?>" name="nama" placeholder="Nama Sumber..." required disabled>

                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label class="control-label">Kecamatan</label>
                            <input type="text" class="form-control" style="display: block;" value="<?php echo e(old('nama',$sumber->kecamatan??'')); ?>" name="nama" placeholder="Nama Sumber..." required disabled>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label class="control-label">Penjaga</label>
                            <input type="text" class="form-control" style="display: block;" value="<?php echo e(old('nama',$sumber->penjaga->nama??'')); ?>" name="nama" placeholder="Nama Sumber..." required disabled>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <div class="row">
        <div class="col-lg-5">
            <div class="panel panel-primary">
                <!-- begin panel-heading -->
                <div class="panel-heading ">
                    <h4 class="panel-title">JENIS DIAMETER</h4>
                </div>
                <div class="panel-body" style=" min-height: 200px;max-height: 200px;overflow-y: scroll;">
                    <form method="POST" action="/sumber/tambah_jenis">
                        <?php echo csrf_field(); ?>
                        <div class="row width-full">
                            <input type="hidden" name="sumber_id" value="<?php echo e($sumber->id); ?>">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label class="control-label">Nama Diameter</label>
                                    <div class="input-group">
                                        <input type="text" name="nama" class="form-control" style="display: block;" required>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="panel-footer">
                            <center>
                                <input type="submit" value="Simpan" class="btn btn-success m-r-3">
                            </center>
                        </div>

                    </form>
                </div>
            </div>
        </div>
        <div class="col-lg-7">
            <div class="panel panel-primary">
                <!-- begin panel-heading -->
                <div class="panel-heading ">
                    <h4 class="panel-title">DAFTAR JENIS DIAMETER</h4>
                </div>
                <div class="panel-body" style=" min-height: 200px;max-height: 200px;overflow-y: scroll;">
                    <div class="row width-full">
                        <div class="panel-body table-responsive">
                            <table class="table table-striped table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>No.</th>
                                        <th>Nama Jenis Diameter</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $jenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($dt->nama); ?></td>
                                        <td>
                                            <a onclick="btnDelete('<?php echo e($dt->id); ?>')" style=" color:red;"><i class="fa fa-trash" aria-hidden="true"></i></a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-3">
            <div class="panel panel-danger">
                <!-- begin panel-heading -->
                <div class="panel-heading ">
                    <h4 class="panel-title">JENIS BAK</h4>
                </div>
                <div class="panel-body" style=" min-height: 200px;max-height: 200px;overflow-y: scroll;">
                    <form method="POST" action="/sumber/tambah_bak">
                        <?php echo csrf_field(); ?>
                        <div class="row width-full">
                            <input type="hidden" name="sumber_id" value="<?php echo e($sumber->id); ?>">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label class="control-label">Nama Bak</label>
                                    <div class="input-group">
                                        <input type="text" name="nama" class="form-control" style="display: block;" required>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="panel-footer">
                            <center>
                                <input type="submit" value="Simpan" class="btn btn-primary m-r-3">
                            </center>
                        </div>

                    </form>
                </div>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="panel panel-danger">
                <!-- begin panel-heading -->
                <div class="panel-heading ">
                    <h4 class="panel-title">DAFTAR JENIS BAK</h4>
                </div>
                <div class="panel-body" style=" min-height: 200px;max-height: 200px;overflow-y: scroll;">
                    <div class="row width-full">
                        <div class="panel-body table-responsive">
                            <table class="table table-striped table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>No.</th>
                                        <th>Nama Jenis BAK</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $jenis_bak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($dt->nama); ?></td>
                                        <td>
                                            <a onclick="btnDeleteBak('<?php echo e($dt->id); ?>')" style=" color:red;"><i class="fa fa-trash" aria-hidden="true"></i></a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-3">
            <div class="panel panel-danger">
                <!-- begin panel-heading -->
                <div class="panel-heading ">
                    <h4 class="panel-title">JAM BACA BAK</h4>
                </div>
                <div class="panel-body" style=" min-height: 200px;max-height: 200px;overflow-y: scroll;">
                    <form method="POST" action="/sumber/tambah_jam_bak">
                        <?php echo csrf_field(); ?>
                        <div class="row width-full">
                            <input type="hidden" name="sumber_id" value="<?php echo e($sumber->id); ?>">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label">Jam</label>
                                    <div class="input-group">
                                        <input type="text" name="jam" class="form-control datetimepicker2" style="display: block;" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="control-label">Pembacaan</label>
                                    <div class="input-group">
                                        <select name="jenis" class="form-control " style="display: block;" required>
                                            <option value="1">Sisa Chlor</option>
                                            <option value="0">Tinggi Air</option>

                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="panel-footer">
                            <center>
                                <input type="submit" value="Simpan" class="btn btn-primary m-r-3">
                            </center>
                        </div>

                    </form>
                </div>
            </div>
        </div>
        <div class="col-lg-3">
            <div class="panel panel-danger">
                <!-- begin panel-heading -->
                <div class="panel-heading ">
                    <h4 class="panel-title">DAFTAR JAM BACA BAK</h4>
                </div>
                <div class="panel-body" style=" min-height: 200px;max-height: 200px;overflow-y: scroll;">
                    <div class="row width-full">
                        <div class="panel-body table-responsive">
                            <table class="table table-striped table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th class="width-60">No.</th>
                                        <th>Jam Baca</th>
                                        <th>Jenis</th>
                                        <th class="width-90"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $jam_bak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e(substr($dt->jam,0,5)); ?></td>
                                        <td width="40%"><?php echo e(($dt->jenis==0)?'Tinggi Air':'Sisa Chlor'); ?></td>
                                        <td>
                                            <a onclick=" btnDeleteJamBak('<?php echo e($dt->id); ?>')" style="color:red;"><i class="fa fa-trash" aria-hidden="true"></i></a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins_scripts'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_scripts'); ?>
<script>
    function btnDelete(id) {
        Swal.fire({
            title: "Yakin?",
            text: "Anda akan menghapus data ini?",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yas, Hapus!"
        }).then(result => {
            if (result.value) {
                $.ajax({
                    url: "/sumber/delete_wm/" + id,
                    type: "POST",
                    data: {
                        _token: "<?php echo e(csrf_token()); ?>"
                    },
                    success: function(response) {
                        console.log(response);
                        if (response != 0) {
                            Swal.fire(
                                "Warning!",
                                "Data gagal dihapus",
                                "warning"
                            ).then(result => {});
                        } else {
                            Swal.fire(
                                "Deleted!",
                                "Data berhasil dihapus",
                                "success"
                            ).then(result => {
                                location.reload();
                            });
                        }
                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                        console.log(textStatus, errorThrown);
                    }
                });
            }
        });
    }

    function btnDeleteBak(id) {
        Swal.fire({
            title: "Yakin?",
            text: "Anda akan menghapus data ini?",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yas, Hapus!"
        }).then(result => {
            if (result.value) {
                $.ajax({
                    url: "/sumber/delete_bak/" + id,
                    type: "GET",
                    success: function(response) {
                        console.log(response);
                        if (response != 0) {
                            Swal.fire(
                                "Warning!",
                                "Data gagal dihapus",
                                "warning"
                            ).then(result => {});
                        } else {
                            Swal.fire(
                                "Deleted!",
                                "Data berhasil dihapus",
                                "success"
                            ).then(result => {
                                location.reload();
                            });
                        }
                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                        console.log(textStatus, errorThrown);
                    }
                });
            }
        });
    }

    function btnDeleteJamBak(id) {
        Swal.fire({
            title: "Yakin?",
            text: "Anda akan menghapus data jam ini?",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yas, Hapus!"
        }).then(result => {
            if (result.value) {
                $.ajax({
                    url: "/sumber/delete_jam_bak/" + id,
                    type: "POST",
                    data: {
                        _token: "<?php echo e(csrf_token()); ?>"
                    },
                    success: function(response) {
                        console.log(response);
                        if (response != 0) {
                            Swal.fire(
                                "Warning!",
                                "Data gagal dihapus",
                                "warning"
                            ).then(result => {});
                        } else {
                            Swal.fire(
                                "Deleted!",
                                "Data berhasil dihapus",
                                "success"
                            ).then(result => {
                                location.reload();
                            });
                        }
                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                        console.log(textStatus, errorThrown);
                    }
                });
            }
        });
    }

    function btnDeleteJam(id) {
        Swal.fire({
            title: "Yakin?",
            text: "Anda akan menghapus data jam ini?",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yas, Hapus!"
        }).then(result => {
            if (result.value) {
                $.ajax({
                    url: "/sumber/delete_jam/" + id,
                    type: "POST",
                    data: {
                        _token: "<?php echo e(csrf_token()); ?>"
                    },
                    success: function(response) {
                        console.log(response);
                        if (response != 0) {
                            Swal.fire(
                                "Warning!",
                                "Data gagal dihapus",
                                "warning"
                            ).then(result => {});
                        } else {
                            Swal.fire(
                                "Deleted!",
                                "Data berhasil dihapus",
                                "success"
                            ).then(result => {
                                location.reload();
                            });
                        }
                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                        console.log(textStatus, errorThrown);
                    }
                });
            }
        });
    }
    $(function() {

        $(".datetimepicker2").datetimepicker({
            format: "HH:mm"
        })
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\sipro\resources\views/pages/sumber/detail.blade.php ENDPATH**/ ?>