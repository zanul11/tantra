

<?php $__env->startSection('title', 'Status Baca'); ?>

<?php $__env->startSection('plugins_styles'); ?>
<link href="<?php echo e(asset('assets/vendors/dataTables/datatables.min.css')); ?>" rel="stylesheet" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="content" class="content">
    <!-- begin breadcrumb -->
    <ol class="breadcrumb pull-right">
        <li class="breadcrumb-item"><a href="<?php echo e(url('/dashboard')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="#">Setup</a></li>
        <li class="breadcrumb-item"><a href=""><?php echo e(Session::get('child')); ?></a></li>
    </ol>
    <!-- end breadcrumb -->
    <!-- begin page-header -->
    <h1 class="page-header text-danger font-weight-bold"><span class="text-custom">DATA</span> <?php echo e(strtoupper(Session::get('child'))); ?></h1>
    <!-- end page-header -->
    <!-- begin row -->
    <div class="row width-full">
        <div class="col-md-4">
            <div class="panel panel-inverse" data-sortable-id="form-stuff-1" style="width: 100%;">
                <!-- begin panel-heading -->

                <div class="panel-heading ui-sortable-handle">
                    <h4 class="panel-title">Form Pajak</h4>
                </div>
                <form method="POST" action="/pajak" enctype='multipart/form-data'>
                    <?php echo csrf_field(); ?>

                    <div class="panel-body">
                        <div class="row width-full">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label class="control-label">PPN (%)</label>
                                    <div class="input-group">
                                        <input type="number" name="ppn" class="form-control" style="display: block;" step="0.01" value="<?php echo e($pajak->ppn??0); ?>" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label class="control-label">PPH (%)</label>
                                    <div class="input-group">
                                        <input type="number" name="pph" class="form-control" style="display: block;" step="0.01" value="<?php echo e($pajak->pph??0); ?>" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label class="control-label">INTERNAL (%)</label>
                                    <div class="input-group">
                                        <input type="number" name="internal" class="form-control" style="display: block;" step="0.01" value="<?php echo e($pajak->internal??0); ?>" required>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="panel-footer">
                        <button type="submit" class="btn btn-success m-r-3">Submit</button>
                    </div>
            </div>

            </form>


        </div>
    </div>

</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins_scripts'); ?>
<script src="<?php echo e(asset('assets/vendors/dataTables/datatables.min.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\pencatatan\resources\views/pages/pajak/index.blade.php ENDPATH**/ ?>