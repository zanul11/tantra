

<?php $__env->startSection('title', 'Satuan'); ?>

<?php $__env->startSection('plugins_styles'); ?>
<link href="<?php echo e(asset('assets/vendors/dataTables/datatables.min.css')); ?>" rel="stylesheet" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="content" class="content">
    <!-- begin breadcrumb -->
    <ol class="breadcrumb pull-right">
        <li class="breadcrumb-item"><a href="<?php echo e(url('/dashboard')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="#">Setup</a></li>
        <li class="breadcrumb-item"><a href="">Tipe & Jenis Kebocoran</a></li>
    </ol>
    <!-- end breadcrumb -->
    <!-- begin page-header -->
    <h1 class="page-header text-danger font-weight-bold"><span class="text-custom"><?php echo e(strtoupper(Session::get('parent'))); ?></span> <?php echo e(strtoupper(Session::get('child'))); ?></h1>

    <!-- end page-header -->
    <!-- begin row -->
    <div class="row width-full">
        <div class="col-md-6">
            <div class="panel panel-inverse" data-sortable-id="form-stuff-1" style="width: 100%;">
                <!-- begin panel-heading -->
                <div class="panel-heading">
                    <div class="row width-full">

                        <div class="col-xl-6 col-sm-6">
                            <div class="form-inline">
                                <a onclick="showModalsAdd()" class="btn btn-primary"><i class="fa fa-plus"></i> Tambah Tipe Kebocoran</a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="panel-body table-responsive">
                    <table class="table table-hover data-table">
                        <thead>
                            <tr>
                                <th class="width-60">No.</th>
                                <th>Tipe</th>
                                <th class="width-90">AKSI</th>
                            </tr>
                        </thead>
                        <tbody>

                        </tbody>
                    </table>
                </div>
                <div class="panel-footer form-inline">
                    <div class="col-md-6 col-lg-10 col-xl-10 col-xs-12">
                        <div>
                        </div>

                    </div>

                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="panel panel-primary" style="width: 100%;">
                <!-- begin panel-heading -->
                <div class="panel-heading">
                    <div class="row width-full">

                        <div class="col-xl-6 col-sm-6">
                            <div class="form-inline">
                                <a onclick="showModalsAddJenis()" class="btn btn-default" style="color: black;"><i class="fa fa-plus"></i> Tambah Jenis Kebocoran</a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="panel-body table-responsive">
                    <table class="table table-hover data-jenis">
                        <thead>
                            <tr>
                                <th class="width-60">No.</th>
                                <th>JENIS</th>
                                <th class="width-90">AKSI</th>
                            </tr>
                        </thead>
                        <tbody>

                        </tbody>
                    </table>
                </div>
                <div class="panel-footer form-inline">
                    <div class="col-md-6 col-lg-10 col-xl-10 col-xs-12">
                        <div>
                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>


    <div class="modal fade" id="modal-add">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Tambah Tipe Kebocoran</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                </div>
                <form class="form-info" novalidate enctype="multipart/form-data" method="post" action="/jenis-tipe" autocomplete="off">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="row">
                            <div class="modal-body">
                                <div class="alert alert-success m-b-0">
                                    <div class="col-lg-12">
                                        <label> Tipe Kebocoran</label>
                                        <input type="text" name="tipe" class="form-control" autofocus></input>
                                        </select>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="modal-footer">
                        <a href="javascript:;" class="btn btn-white" data-dismiss="modal">Close</a>
                        <button type="submit" class="btn btn-primary" id="btn-submit">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="modal-edit">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Edit Tipe Kebocoran</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                </div>
                <form class="form-info" novalidate enctype="multipart/form-data" method="post" action="/tipe/edit" autocomplete="off">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="row">
                            <div class="modal-body">
                                <div class="alert alert-success m-b-0">
                                    <div class="col-lg-12">
                                        <label> Tipe Kebocoran </label>
                                        <input type="text" name="tipe" id="tipe_edit" class="form-control"></input>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <input type="hidden" name="id_tipe" id="id_tipe"></input>

                        </div>
                    </div>
                    <div class="modal-footer">
                        <a href="javascript:;" class="btn btn-white" data-dismiss="modal">Close</a>
                        <button type="submit" class="btn btn-primary" id="btn-submit">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="modal-add-jenis">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Tambah Jenis Kebocoran</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                </div>
                <form class="form-info" novalidate enctype="multipart/form-data" method="post" action="/jenis" autocomplete="off">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="row">
                            <div class="modal-body">
                                <div class="alert alert-warning m-b-0">
                                    <div class="col-lg-12">
                                        <label> Nama Jenis </label>
                                        <input type="text" name="jenis" class="form-control" autofocus></input>
                                        </select>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="modal-footer">
                        <a href="javascript:;" class="btn btn-white" data-dismiss="modal">Close</a>
                        <button type="submit" class="btn btn-primary" id="btn-submit">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="modal-edit-jenis">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Edit Jenis Kebocoran</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                </div>
                <form class="form-info" novalidate enctype="multipart/form-data" method="post" action="/jenis/edit" autocomplete="off">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="row">
                            <div class="modal-body">
                                <div class="alert alert-warning m-b-0">
                                    <div class="col-lg-12">
                                        <label> Nama Jenis </label>
                                        <input type="text" name="jenis" id="jenis_edit" class="form-control"></input>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <input type="hidden" name="id_jenis" id="id_jenis"></input>

                        </div>
                    </div>
                    <div class="modal-footer">
                        <a href="javascript:;" class="btn btn-white" data-dismiss="modal">Close</a>
                        <button type="submit" class="btn btn-primary" id="btn-submit">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins_scripts'); ?>
<script src="<?php echo e(asset('assets/vendors/dataTables/datatables.min.js')); ?>"></script>
<script>
    function showModalsAdd() {
        // document.getElementById("id_laporan").value = kode;
        // // document.getElementById("btn-submit").value = '';
        $('#modal-add').modal({
            backdrop: 'static',
            keyboard: false
        });
    }

    function showModalsEdit(kode, tipe) {
        document.getElementById("id_tipe").value = kode;
        document.getElementById("tipe_edit").value = tipe;
        $('#modal-edit').modal({
            backdrop: 'static',
            keyboard: false
        });
    }

    function showModalsAddJenis() {
        // document.getElementById("id_laporan").value = kode;
        // // document.getElementById("btn-submit").value = '';
        $('#modal-add-jenis').modal({
            backdrop: 'static',
            keyboard: false
        });
    }

    function showModalsEditJenis(kode, jenis) {
        document.getElementById("id_jenis").value = kode;
        document.getElementById("jenis_edit").value = jenis;
        $('#modal-edit-jenis').modal({
            backdrop: 'static',
            keyboard: false
        });
    }
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_scripts'); ?>
<script>
    $(function() {
        $(document).ready(function() {
            $('.data-table').DataTable({
                processing: true,
                serverSide: true,
                pageLength: 5,
                lengthChange: false,
                responsive: true,
                ajax: "<?php echo e(route('ss.tipe')); ?>",
                columns: [{
                        "data": "DT_RowIndex"
                    }, {
                        "data": "tipe"
                    },
                    {
                        "data": "action"
                    },

                ],
            });

            $('.data-jenis').DataTable({
                processing: true,
                serverSide: true,
                pageLength: 5,
                lengthChange: false,
                responsive: true,
                ajax: "<?php echo e(route('ss.jenis')); ?>",
                columns: [{
                        "data": "DT_RowIndex"
                    }, {
                        "data": "jenis"
                    },
                    {
                        "data": "action"
                    },

                ],
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\sipro\resources\views/pages/jenis-tipe/index.blade.php ENDPATH**/ ?>