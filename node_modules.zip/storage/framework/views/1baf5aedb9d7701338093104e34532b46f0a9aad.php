

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('plugins_styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="content" class="content">
    <!-- begin breadcrumb -->
    <ol class="breadcrumb pull-right">
        <li class="breadcrumb-item"><a href="<?php echo e(url('/dashboard')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item"><a>Data Master</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(url('/sumber')); ?>">SUMBER</a></li>
        <li class="breadcrumb-item"><a>Tambah Data</a></li>
    </ol>
    <!-- end breadcrumb -->
    <!-- begin page-header -->
    <h1 class="page-header text-danger font-weight-bold"><span class="text-custom">TAMBAH DATA</span> SUMBER</h1>


    <div class="panel panel-inverse" data-sortable-id="form-stuff-1">
        <!-- begin panel-heading -->
        <div class="panel-heading ui-sortable-handle">
            <h4 class="panel-title">Form Tambah Data</h4>

        </div>
        <form method="POST" action="<?php echo e(($action=='add')?'/sumber':'/sumber/'.$sumber->id); ?>">
            <?php echo csrf_field(); ?>
            <?php if($action!='add'): ?>
            <?php echo method_field('PUT'); ?>
            <?php endif; ?>
            <div class="panel-body">
                <div class="row width-full">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">Nama Sumber</label>
                            <div class="input-group">
                                <input type="text" class="form-control" style="display: block;" value="<?php echo e(old('nama',$sumber->nama??'')); ?>" name="nama" placeholder="Nama Sumber..." required>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label class="control-label">Hitung Masuk</label>
                            <div class="input-group">
                                <select class="selectpicker show-tick form-control required" name="status" data-style="btn-warning" required>
                                    <option value="Tidak" <?php echo e(old('jenis',$sumber->jenis??'')=='Tidak' ? 'selected' : ''); ?>>Tidak</option>
                                    <option value="Ya" <?php echo e(old('jenis',$sumber->jenis??'')=='Ya' ? 'selected' : ''); ?>>Ya</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label class="control-label">Hitung Masuk</label>
                            <div class="input-group">
                                <select class="selectpicker show-tick form-control required" name="status" data-style="btn-warning" required>
                                    <option value="Tidak" <?php echo e(old('jenis',$sumber->jenis??'')=='Tidak' ? 'selected' : ''); ?>>Tidak</option>
                                    <option value="Ya" <?php echo e(old('jenis',$sumber->jenis??'')=='Ya' ? 'selected' : ''); ?>>Ya</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="panel-footer">
                <input type="submit" value="Simpan" class="btn btn-success m-r-3">
                <a wire:click="batal" class="btn btn-danger">Batal</a>
            </div>
    </div>

    </form>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins_scripts'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_scripts'); ?>
<script>

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\sipro\resources\views/pages/sumber/create_sumber.blade.php ENDPATH**/ ?>