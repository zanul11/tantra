

<?php $__env->startSection('title', 'User'); ?>

<?php $__env->startSection('plugins_styles'); ?>
<link href="<?php echo e(asset('assets/vendors/dataTables/datatables.min.css')); ?>" rel="stylesheet" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_styles'); ?>
<style>
    #fullpage {
        display: none;
        position: absolute;
        z-index: 9999;
        top: 0;
        left: 0;
        width: 100vw;
        height: 100vh;
        background-size: contain;
        background-repeat: no-repeat no-repeat;
        background-position: center center;
        background-color: white;
    }

    .zoom {

        transition: transform .08s;
        width: 214px;
        height: 115px;
    }

    .zoom:hover {
        -ms-transform: scale(1.5);
        /* IE 9 */
        -webkit-transform: scale(1.5);
        /* Safari 3-8 */
        transform: scale(1.5);
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- end #sidebar-right -->

<!-- begin #content -->
<div id="content" class="content">
    <!-- begin breadcrumb -->
    <ol class="breadcrumb pull-right">
        <li class="breadcrumb-item"><a href="/dashboard">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="javascript:;">Catatan</a></li>
        <li class="breadcrumb-item active">Catatan Tinggi Muka Air</li>
    </ol>
    <!-- end breadcrumb -->
    <!-- begin page-header -->
    <h1 class="page-header text-danger font-weight-bold"><span class="text-custom">CATATAN</span> TINGGI MUKA IAR</h1>
    <!-- end page-header -->

    <!-- begin panel -->
    <div class="panel panel-inverse">
        <div class="panel-heading">
            <h4 class="panel-title">Data Catatan Tinggi Muka Air</h4>
        </div>
        <div class="panel-body">
            <form method="POST" action="/tinggi/filter">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-lg-2">
                        <label> Dari tanggal </label>
                        <input type="date" class="form-control" name="dTgl" value="<?php echo e(date('Y-m-d', strtotime(Session::get('dTgl')))); ?>">
                    </div>
                    <div class="col-lg-2">
                        <label> Sampai </label>
                        <input type="date" class="form-control" name="sTgl" value="<?php echo e(date('Y-m-d', strtotime(Session::get('sTgl')))); ?>">
                    </div>
                    <div class="col-lg-3">
                        <label> Sumber & Sumur Bor </label>
                        <div class="input-group">
                            <select class="selectpicker show-tick form-control required" data-live-search="true" name="sumber" data-style="btn-primary" required>
                                <option value="Semua" <?php echo e(Session::get('sumber')=='Semua'?'selected':''); ?>>Semua</option>
                                <?php $__currentLoopData = $data_sumber; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($dt->id); ?>" <?php echo e(Session::get('sumber')==$dt->id?'selected':''); ?>><?php echo e($dt->nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="col-lg-1">
                        <label> # </label>
                        <button type="submit" class="form-control btn btn-green" id="Button"> Filter</button>
                    </div>
            </form>
            <div class="col-lg-1">
                <label> # </label>
                <a href="/tinggi/1" target="_blank" class="form-control btn btn-info " id="Button"> Cetak </a>
            </div>
            <br><br> <br><br> <br><br>
            <table class="table table-hover data-table table-striped">
                <thead>
                    <tr>
                        <th class="width-10">No.</th>
                        <th>Tanggal</th>
                        <th>Sumber</th>
                        <th>BAK / Jam Baca</th>
                        <th>Petugas</th>
                        <th>Tinggi Muka Air</th>
                        <th>Foto</th>
                        <th>Ket</th>
                        <th class="width-90">Aksi</th>
                    </tr>
                </thead>
                <tbody>


                </tbody>
            </table><br>
        </div>
    </div>
    <!-- end panel -->
    <div id="fullpage" onclick="this.style.display='none';"></div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins_scripts'); ?>
<script src="<?php echo e(asset('assets/vendors/dataTables/datatables.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_scripts'); ?>
<script>
    imgs = document.querySelectorAll('.gallery img');
    fullPage = document.querySelector('#fullpage');

    function srcImage() {
        const img = document.querySelector('img');
        fullPage.style.backgroundImage = 'url(' + event.target.getAttribute('src') + ')';
        fullPage.style.display = 'block';
    }
    $(function() {
        $(document).ready(function() {
            $('.data-table').DataTable({
                processing: true,
                serverSide: true,
                pageLength: 10,

                responsive: true,
                ajax: "<?php echo e(route('ss.tinggi')); ?>",
                columns: [{
                        "data": "DT_RowIndex"
                    }, {
                        "data": "tanggal"
                    },
                    {
                        "data": "sumber.nama"
                    },
                    {
                        "data": "bak"
                    },
                    {
                        "data": "petugas"
                    },
                    {
                        "data": "tinggi"
                    },
                    {
                        "data": "foto"
                    }, {
                        "data": "ket"
                    },
                    {
                        "data": "action"
                    },
                ],
                "columnDefs": [{
                    "targets": 6,
                    "data": "foto",
                    "render": function(data, type, row, meta) {
                        var type = '';
                        if (data != null) {
                            type = '<img src="' + data + '" onclick="srcImage()" height="50px"/>';
                        } else {
                            type = '-';
                        }
                        return type;

                    }
                }, ],

            });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\sipro\resources\views/pages/tinggi_muka/index.blade.php ENDPATH**/ ?>