

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('plugins_styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="content" class="content">
    <!-- begin breadcrumb -->
    <ol class="breadcrumb pull-right">
        <li class="breadcrumb-item"><a href="<?php echo e(url('/dashboard')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="javascript:;"><?php echo e(Session::get('parent')); ?></a></li>
        <li class="breadcrumb-item"><?php echo e(Session::get('child')); ?></li>
        <li class="breadcrumb-item active"><a>Form Progres</a></li>
    </ol>
    <!-- end breadcrumb -->
    <!-- begin page-header -->
    <h1 class="page-header text-danger font-weight-bold"><span class="text-custom">PROGRES DOKUMEN <?php echo e(strtoupper($dokumen->jenis)); ?></span> <?php echo e(strtoupper($dokumen->sumber->nama)); ?></h1>
    <div class="row">
        <div class="col-lg-6">
            <div class="panel panel-inverse" data-sortable-id="form-stuff-1">
                <!-- begin panel-heading -->
                <div class="panel-heading ui-sortable-handle">
                    <h4 class="panel-title">Form</h4>
                </div>
                <form method="POST" action="/dokumen/progres">
                    <?php echo csrf_field(); ?>
                    <div class="panel-body">
                        <div class="row width-full">
                            <input type="hidden" value="<?php echo e($dokumen->id); ?>" name="dokumen_id" />
                            <?php $__currentLoopData = $data_progres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label class="control-label"><?php echo e(strtoupper($dt->progres)); ?></label>
                                    <div class="input-group">
                                        <select class="selectpicker show-tick form-control required" name="status[]" data-style="btn-<?php echo e(($dt->status==0)?'danger':'green'); ?>" required>
                                            <option value="0" <?php echo e(($dt->status==0)?'selected':''); ?>>BELUM SELESAI</option>
                                            <option value="1" <?php echo e(($dt->status==1)?'selected':''); ?>>SELESAI</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-9">
                                <div class="form-group">
                                    <label class="control-label">Ket</label>
                                    <div class="input-group">
                                        <textarea class="form-control" name="ket[]"><?php echo e($dt->ket??''); ?></textarea>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="panel-footer">
                        <input type="submit" value="Simpan" class="btn btn-success m-r-3">
                        <a wire:click="batal" class="btn btn-danger">Batal</a>
                    </div>
                </form>
            </div>
        </div>
    </div>



</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins_scripts'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\sipro\resources\views/pages/dokumen/progres.blade.php ENDPATH**/ ?>