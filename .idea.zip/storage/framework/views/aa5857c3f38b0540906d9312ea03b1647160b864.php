

<?php $__env->startSection('title', 'User'); ?>

<?php $__env->startSection('plugins_styles'); ?>
<link href="<?php echo e(asset('assets/vendors/dataTables/datatables.min.css')); ?>" rel="stylesheet" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_styles'); ?>
<style>
    #fullpage {
        display: none;
        position: absolute;
        z-index: 9999;
        top: 0;
        left: 0;
        width: 100vw;
        height: 100vh;
        background-size: contain;
        background-repeat: no-repeat no-repeat;
        background-position: center center;
        background-color: white;
    }

    .zoom {

        transition: transform .08s;
        width: 214px;
        height: 115px;
    }

    .zoom:hover {
        -ms-transform: scale(1.5);
        /* IE 9 */
        -webkit-transform: scale(1.5);
        /* Safari 3-8 */
        transform: scale(1.5);
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- end #sidebar-right -->

<!-- begin #content -->
<div id="content" class="content">
    <!-- begin breadcrumb -->
    <ol class="breadcrumb pull-right">
        <li class="breadcrumb-item"><a href="/dashboard">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="javascript:;">Catatan</a></li>
        <li class="breadcrumb-item active">Kebocoran</li>
    </ol>
    <!-- end breadcrumb -->
    <!-- begin page-header -->
    <h1 class="page-header text-danger font-weight-bold"><span class="text-custom">CATATAN</span> KEBOCORAN</h1>
    <!-- end page-header -->

    <!-- begin panel -->
    <div class="panel panel-inverse">
        <div class="panel-heading">
            <h4 class="panel-title">Data Kebocoran</h4>
        </div>
        <div class="panel-body">
            <form method="POST" action="/kebocoran/filter">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-lg-2">
                        <label> Dari tanggal </label>
                        <input type="date" class="form-control" name="dTgl" value="<?php echo e(date('Y-m-d', strtotime(Session::get('dTgl')))); ?>">
                    </div>
                    <div class="col-lg-2">
                        <label> Sampai </label>
                        <input type="date" class="form-control" name="sTgl" value="<?php echo e(date('Y-m-d', strtotime(Session::get('sTgl')))); ?>">
                    </div>
                    <div class="col-lg-1">
                        <label> # </label>
                        <button type="submit" class="form-control btn btn-green" id="Button"> Filter</button>
                    </div>
            </form>
            <div class="col-lg-1">
                <label> # </label>
                <a href="/kebocoran/1" target="_blank" class="form-control btn btn-info " id="Button"> Cetak </a>
            </div>
            <br><br> <br><br> <br><br>
            <table class="table table-hover data-table table-striped">
                <thead>
                    <tr>
                        <th class="width-10">No.</th>
                        <th>Tgl Input / dikerjakan / Selesai</th>
                        <th>Diameter/Jenis/Tipe</th>
                        <th>Keterangan</th>
                        <th>Foto Sebelum</th>
                        <th>Foto Sesudah</th>
                        <th>Foto Selesai</th>
                        <th>Status</th>
                        <th class="width-90">Petugas</th>
                    </tr>
                </thead>
                <tbody>


                </tbody>
            </table><br>
        </div>
    </div>
    <!-- end panel -->
    <div id="fullpage" onclick="this.style.display='none';"></div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins_scripts'); ?>
<script src="<?php echo e(asset('assets/vendors/dataTables/datatables.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_scripts'); ?>
<script>
    imgs = document.querySelectorAll('.gallery img');
    fullPage = document.querySelector('#fullpage');

    function srcImage() {
        const img = document.querySelector('img');
        fullPage.style.backgroundImage = 'url(' + event.target.getAttribute('src') + ')';
        fullPage.style.display = 'block';
    }
    $(function() {
        $(document).ready(function() {
            $('.data-table').DataTable({
                processing: true,
                serverSide: true,
                pageLength: 10,

                responsive: true,
                ajax: "<?php echo e(route('ss.kebocoran')); ?>",
                columns: [{
                        "data": "DT_RowIndex"
                    }, {
                        "data": "tanggal"
                    },
                    {
                        "data": "nama"
                    },
                    {
                        "data": "ket"
                    },
                    {
                        "data": "foto_sebelum"
                    },
                    {
                        "data": "foto_sedang"
                    },
                    {
                        "data": "foto_sesudah"
                    }, {
                        "data": "status"
                    },
                    {
                        "data": "user"
                    },
                ],
                "columnDefs": [{
                    "targets": 4,
                    "data": "foto_sebelum",
                    "render": function(data, type, row, meta) {
                        var type = '';
                        if (data != null) {
                            type = '<img src="' + data + '" onclick="srcImage()" height="50px"/>';
                        } else {
                            type = '-';
                        }
                        return type;

                    }
                }, {
                    "targets": 5,
                    "data": "foto_sedang",
                    "render": function(data, type, row, meta) {
                        var type = '';
                        if (data != null) {
                            type = '<img src="' + data + '" onclick="srcImage()" height="50px"/>';
                        } else {
                            type = '-';
                        }
                        return type;

                    }
                }, {
                    "targets": 6,
                    "data": "foto_sesudah",
                    "render": function(data, type, row, meta) {
                        var type = '';
                        if (data != null) {
                            type = '<img src="' + data + '" onclick="srcImage()" height="50px"/>';
                        } else {
                            type = '-';
                        }
                        return type;

                    }
                }, {
                    "targets": 7,
                    "data": "status",
                    "render": function(data, type, row, meta) {
                        var type = '';
                        if (data == 1) {
                            type = '<span class="label label-warning">Belum Dikerjakan</span>';
                        } else if (data == 2) {
                            type = '<span class="label label-primary">Sedang Dikerjakan</span>';
                        } else {
                            type = '<span class="label label-green">Selesai</span>';
                        }
                        return type;

                    }
                }],

            });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\sipro\resources\views/pages/kebocoran/index.blade.php ENDPATH**/ ?>