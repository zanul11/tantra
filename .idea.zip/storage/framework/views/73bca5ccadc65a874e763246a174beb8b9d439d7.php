

<?php $__env->startSection('title', 'User'); ?>

<?php $__env->startSection('plugins_styles'); ?>
<link href="<?php echo e(asset('assets/vendors/dataTables/datatables.min.css')); ?>" rel="stylesheet" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- end #sidebar-right -->

<!-- begin #content -->
<div id="content" class="content">
    <!-- begin breadcrumb -->
    <ol class="breadcrumb pull-right">
        <li class="breadcrumb-item"><a href="/dashboard">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="javascript:;"><?php echo e(Session::get('parent')); ?></a></li>
        <li class="breadcrumb-item active"><?php echo e(Session::get('child')); ?></li>
    </ol>
    <!-- end breadcrumb -->
    <!-- begin page-header -->
    <h1 class="page-header text-danger font-weight-bold"><span class="text-custom"><?php echo e(strtoupper(Session::get('parent'))); ?></span> <?php echo e(strtoupper(Session::get('child'))); ?></h1>
    <!-- end page-header -->

    <!-- begin panel -->
    <div class="panel panel-inverse">
        <div class="panel-heading">
            <div class="panel-heading-btn">
                <a href="<?php echo e(route('dokumen.create')); ?>" class="f-s-15 btn btn-xs text-white"><i class="fa fa-plus-square"></i></a> <a target="_blank" href="/dokumen/cetak" class="f-s-15 btn btn-xs text-white"><i class="fa fa-print"></i></a>
            </div>
            <h4 class="panel-title">Data <?php echo e(Session::get('child')); ?></h4>
        </div>
        <div class="panel-body">
            <table class="table table-hover data-table table-striped">
                <thead>
                    <tr>
                        <th class="width-10">No.</th>
                        <th>Sumber</th>
                        <th>Jenis</th>
                        <th>Nomor</th>
                        <th>Tanggal Dokumen</th>
                        <th>Ket</th>
                        <th>Progres</th>
                        <th class="width-90">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table><br>
        </div>
    </div>
    <!-- end panel -->
    <div id="fullpage" onclick="this.style.display='none';"></div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins_scripts'); ?>
<script src="<?php echo e(asset('assets/vendors/dataTables/datatables.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_scripts'); ?>
<script>
    function btnDelete(kode) {
        Swal.fire({
            title: "Yakin?",
            text: "Anda akan menghapus data ini?",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yas, Hapus!"
        }).then(result => {
            if (result.value) {
                $.ajax({
                    url: "/dokumen/" + kode,
                    type: "DELETE",
                    data: {
                        _token: "<?php echo e(csrf_token()); ?>"
                    },
                    success: function(response) {
                        Swal.fire(
                            "Deleted!",
                            "Data berhasil dihapus",
                            "success"
                        ).then(result => {
                            location.reload();
                        });
                        // You will get response from your PHP page (what you echo or print)
                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                        console.log(textStatus, errorThrown);
                    }
                });
            }
        });
    }
    $(function() {
        $(document).ready(function() {
            $('.data-table').DataTable({
                processing: true,
                serverSide: true,
                pageLength: 10,

                responsive: true,
                ajax: "<?php echo e(route('ss.dokumen')); ?>",
                columns: [{
                        "data": "DT_RowIndex"
                    },
                    {
                        "data": "sumber"
                    }, {
                        "data": "jenis"
                    },
                    {
                        "data": "nomor"
                    },
                    {
                        "data": "tgl"
                    }, {
                        "data": "ket"
                    },
                    {
                        "data": "log"
                    },
                    {
                        "data": "action"
                    },
                ],
                "columnDefs": [{
                    "targets": 6,
                    "data": "log",
                    "render": function(data, type, row, meta) {
                        var head = '<table class="table table-sm alert alert-primary"> <tr><th>Progres</th><th style="text-align: center;">Status</th><th style="text-align: center;">Tgl</th><th>Ket</th> </tr>';
                        var foot = '</table>';
                        var isi = '';
                        data.forEach((element) => {
                            var status = '<i class="fa fa-times" aria-hidden="true" style="color:red"></i>';
                            if (element['status'] == 1)
                                status = '<i class="fa fa-check" aria-hidden="true" style="color:green"></i>';
                            isi += '<tr><td width="30%">' + element['progres'] + '</td><td style="text-align: center;" width="10%">' + status + '</td><td style="text-align: center;" width="20%">' + element['tgl'] + '</td><td>' + element['ket'] + '</td> </tr>';
                        });
                        return head + isi + foot;
                    }
                }]
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\sipro\resources\views/pages/dokumen/index.blade.php ENDPATH**/ ?>