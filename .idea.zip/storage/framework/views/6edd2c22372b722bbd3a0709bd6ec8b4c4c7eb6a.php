

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('plugins_styles'); ?>
<link href="<?php echo e(asset('assets/vendors/jvectormap/jquery-jvectormap-2.0.3.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('assets/vendors/dataTables/datatables.min.css')); ?>" rel="stylesheet" />
<link href="https://cdn.jsdelivr.net/npm/bs-stepper/dist/css/bs-stepper.min.css" rel="stylesheet" />
<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>
<script src="https://code.highcharts.com/modules/accessibility.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="content" class="content">
    <!-- begin breadcrumb -->
    <ol class="breadcrumb pull-right">
        <li class="breadcrumb-item"><a href="javascript:;">Home</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(url('/dashboard')); ?>">Dashboard</a></li>

    </ol>
    <!-- end breadcrumb -->
    <!-- begin page-header -->
    <h1 class="page-header">Selamat Datang <small>di Aplikasi Inventaris</small></h1>
    <!-- end page-header -->
    <!-- begin row -->
    <div class="row">
        <!-- begin col-3 -->

        <!-- end col-3 -->
        <!-- begin col-3 -->
        <div class="col-lg-4 col-md-12">
            <div class="widget widget-stats bg-orange">
                <div class="stats-icon"><i class="fa fa-window-restore"></i></div>
                <div class="stats-info">
                    <h4>Mata Air</h4>
                    <p><?php echo e($sumber); ?></p>
                </div>
                <div class="stats-link">
                    <a href="<?php echo e(route('sumber.index')); ?>">View Detail <i class="fa fa-arrow-alt-circle-right"></i></a>
                </div>
            </div>
        </div>

        <div class="col-lg-4 col-md-12">
            <div class="widget widget-stats bg-purple">
                <div class="stats-icon"><i class="fa fa-cubes"></i></div>
                <div class="stats-info">
                    <h4>SUMUR BOR</h4>
                    <p><?php echo e($sumur); ?></p>
                </div>
                <div class="stats-link">
                    <a href="<?php echo e(route('sumber.index')); ?>">View Detail <i class="fa fa-arrow-alt-circle-right"></i></a>
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-md-12">
            <div class="widget widget-stats bg-green">
                <div class="stats-icon"><i class="fa fa-users"></i></div>
                <div class="stats-info">
                    <h4>SUNGAI</h4>
                    <p><?php echo e($sungai); ?></p>
                </div>
                <div class="stats-link">
                    <a href="<?php echo e(route('sumber.index')); ?>">View Detail <i class="fa fa-arrow-alt-circle-right"></i></a>
                </div>
            </div>
        </div>
        <div class="col-lg-12 col-md-12">
            <div class="panel panel-inverse" data-sortable-id="form-stuff-1">
                <!-- begin panel-heading -->
                <div class="panel-heading ui-sortable-handle">
                    <h4 class="panel-title">INFORMASI DOKUMEN YANG AKAN BERAKHIR IZINNYA</h4>
                </div>
                <div class="panel-body table-responsive ">
                    <table class="table table-hover table-striped data-table">
                        <thead>
                            <tr>
                                <th class="width-60">NO.</th>
                                <th>JENIS</th>
                                <th>SUMBER/SUMUR </th>
                                <th>NOMOR</th>
                                <th>TGL BERAKHIR</th>
                                <th>KET</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $dok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="width-60"><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($dt->jenis); ?> </td>
                                <td><?php echo e($dt->sumber->nama); ?></td>
                                <td><?php echo e($dt->nomor); ?></td>
                                <td><?php echo e(date('d-m-Y', strtotime($dt->tgl_berakhir))); ?></td>
                                <td><?php echo e($dt->ket); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
                <div class="panel-footer form-inline">
                    <div class="col-md-6 col-lg-10 col-xl-10 col-xs-12">
                        <div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- end col-3 -->
        <!-- begin col-3 -->
        <!-- <div class="col-lg-3 col-md-6">
            <div class="widget widget-stats bg-gradient-purple">
                <div class="stats-icon stats-icon-lg"><i class="fa fa-archive fa-fw"></i></div>
                <div class="stats-content">
                    <div class="stats-title">NEW ORDERS</div>
                    <div class="stats-number">38,900</div>
                    <div class="stats-progress progress">
                        <div class="progress-bar" style="width: 76.3%;"></div>
                    </div>
                    <div class="stats-desc">Better than last week (76.3%)</div>
                </div>
            </div>
        </div> -->
        <!-- end col-3 -->
        <!-- begin col-3 -->
        <!-- <div class="col-lg-3 col-md-6">
            <div class="widget widget-stats bg-gradient-black">
                <div class="stats-icon stats-icon-lg"><i class="fa fa-comment-alt fa-fw"></i></div>
                <div class="stats-content">
                    <div class="stats-title">NEW COMMENTS</div>
                    <div class="stats-number">3,988</div>
                    <div class="stats-progress progress">
                        <div class="progress-bar" style="width: 54.9%;"></div>
                    </div>
                    <div class="stats-desc">Better than last week (54.9%)</div>
                </div>
            </div>
        </div> -->
        <!-- end col-3 -->
    </div>
    <!-- end row -->
    <!-- begin row -->
    <!-- end row -->
    <!-- begin row -->
    <!-- end row -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins_scripts'); ?>
<script src="<?php echo e(asset('assets/vendors/dataTables/datatables.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_scripts'); ?>
<script>
    $(function() {
        $(document).ready(function() {
            $('.data-table').DataTable({
                searching: false,
                pageLength: 7,
                lengthChange: false,
                responsive: true,
            });
        });
    });
    var nama = JSON.parse('<?php echo e(json_encode(Auth::user()->nama)); ?>'.replace(/&quot;/g, '"'));
    handleDashboardGritterNotification = function() {
        setTimeout(function() {
            $.gritter.add({
                title: "SELAMAT DATANG " + nama,
                text: "Selamat bekerja dan semoga sukses",
                image: "../assets/img/users/user.png",
                sticky: !0,
                time: "",
                class_name: "my-sticky-class"
            });
        }, 1e3)
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\sipro\resources\views/pages/dashboard/index.blade.php ENDPATH**/ ?>