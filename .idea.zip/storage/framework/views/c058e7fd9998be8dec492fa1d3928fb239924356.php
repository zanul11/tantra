<div id="sidebar" class="sidebar">
    <!-- begin sidebar scrollbar -->
    <div data-scrollbar="true" data-height="100%">
        <!-- begin sidebar user -->
        <ul class="nav">
            <li class="nav-profile">
                <a href="javascript:;" data-toggle="nav-profile">
                    <div class="cover with-shadow"></div>
                    <div class="image">
                        <img src="<?php echo e(asset('assets/img/users/user.png')); ?>" alt="" />
                    </div>
                    <div class="info">
                        <b class="caret pull-right"></b>
                        <?php echo e(Auth::user()->nama); ?>

                        <small><span class="label label-primary"><?php echo e((Auth::user()->type==1)?'SUPER ADMIN':'USER'); ?></span></small>
                    </div>
                </a>
            </li>

        </ul>
        <!-- end sidebar user -->
        <!-- begin sidebar nav -->
        <ul class="nav">
            <li class="nav-header">Menus</li>

            <!-- begin sidebar minify button -->
            <!-- end sidebar minify button -->
            <?php $__currentLoopData = Auth::user()->menus(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($parent->status==1): ?>
            <li class="has-sub <?php echo e(Session::get('parent') == $parent->nm_menu ? 'active':''); ?>">
                <?php if($parent->nm_menu!='Dashboard'): ?>
                <a href="javascript:;">
                    <b class="caret"></b>
                    <i class="fa <?php echo e($parent->icon); ?>"></i>
                    <span><?php echo e($parent->nm_menu); ?></span>
                </a>
                <ul class="sub-menu">
                    <?php $__currentLoopData = Auth::user()->menus(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($child->status==0 AND $child->kd_parent==$parent->kd_menu): ?>
                    <li class="<?php echo e(Session::get('child') == $child->nm_menu ? 'active':''); ?>"><a href="<?php echo e(url($child->route)); ?>"><?php echo e($child->nm_menu); ?> </a></li>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <?php else: ?>
                <a href="<?php echo e($parent->route); ?>">

                    <i class="fa <?php echo e($parent->icon); ?>"></i>
                    <span><?php echo e($parent->nm_menu); ?></span>
                </a>
                <?php endif; ?>

            </li>

            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <li><a href="javascript:;" class="sidebar-minify-btn" data-click="sidebar-minify"><i class="fa fa-angle-double-left"></i></a></li>

        </ul>
        <!-- end sidebar nav -->
    </div>
    <!-- end sidebar scrollbar -->
</div>
<div class="sidebar-bg"></div><?php /**PATH D:\laragon\www\pencatatan\resources\views/includes/sidebar.blade.php ENDPATH**/ ?>