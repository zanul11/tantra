

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('plugins_styles'); ?>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="content" class="content">
    <!-- begin breadcrumb -->
    <ol class="breadcrumb pull-right">
        <li class="breadcrumb-item"><a href="<?php echo e(url('/dashboard')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item"><a>Form Data</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(url('/wm')); ?>">Water Meter</a></li>
        <li class="breadcrumb-item"><a>Edit Data</a></li>
    </ol>
    <!-- end breadcrumb -->
    <!-- begin page-header -->
    <h1 class="page-header text-danger font-weight-bold"><span class="text-custom">EDIT DATA</span> BACAAN WATER METER</h1>
    <div class="panel panel-inverse ">
        <!-- begin panel-heading -->
        <div class="panel-heading ui-sortable-handle">
            <h4 class="panel-title">Form Edit Data</h4>

        </div>
        <form method="POST" action="<?php echo e(($action=='add')?'/wm':'/wm/'.$wm->id); ?>">
            <?php echo csrf_field(); ?>
            <?php if($action!='add'): ?>
            <?php echo method_field('PUT'); ?>
            <?php endif; ?>
            <div class="panel-body">
                <div class="row width-full">
                    <div class="col-md-2">
                        <div class="form-group">
                            <label class="control-label">Tempat</label>
                            <div class="input-group">
                                <input type="text" class="form-control" style="display: block;" value="<?php echo e(($action!='add')?$wm->sumber->nama.'/'.$wm->sumber->kecamatan:''); ?>" name="nama" disabled>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label class="control-label">Jenis WM / Jam Baca</label>
                            <div class="input-group">
                                <input type="text" class="form-control" style="display: block;" value="<?php echo e(($action!='add')?$wm->jenis_wm->nama.' / '.$wm->jam_baca->jam:''); ?>" readonly>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-2">
                        <div class="form-group">
                            <label class="control-label">Tanggal</label>
                            <div class="input-group">
                                <input type="date" class="form-control" value="<?php echo e(old('tgl',date('Y-m-d',strtotime($wm->tgl??date('d-m-Y')))??date('Y-m-d'))); ?>" name="tgl" required>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-2">
                        <label> Status Baca </label>
                        <select name="status_id" class="selectpicker form-control" data-style="btn-info">
                            <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($dt->id); ?>" <?php echo e($wm->status_id==$dt->id?'selected':''); ?>><?php echo e($dt->status); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label class="control-label">Stan</label>
                            <div class="input-group">
                                <input type="number" class="form-control" style="display: block;" value="<?php echo e(($action!='add')?$wm->stan_ini:''); ?>" name="stan_ini" required>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="panel-footer">
                <input type="submit" value="Simpan" class="btn btn-success m-r-3">
                <a wire:click="batal" class="btn btn-danger">Batal</a>
            </div>
    </div>

    </form>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins_scripts'); ?>

<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_scripts'); ?>
<script>
    $(document).ready(function() {
        $('.select2').select2();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\sipro\resources\views/pages/water_meter/create.blade.php ENDPATH**/ ?>