

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('plugins_styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="content" class="content">
    <!-- begin breadcrumb -->
    <ol class="breadcrumb pull-right">
        <li class="breadcrumb-item"><a href="<?php echo e(url('/dashboard')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="javascript:;"><?php echo e(Session::get('parent')); ?></a></li>
        <li class="breadcrumb-item"><?php echo e(Session::get('child')); ?></li>
        <li class="breadcrumb-item active"><a>Tambah Data</a></li>
    </ol>
    <!-- end breadcrumb -->
    <!-- begin page-header -->
    <h1 class="page-header text-danger font-weight-bold"><span class="text-custom">FORM <?php echo e(strtoupper(Session::get('parent'))); ?></span> <?php echo e(strtoupper(Session::get('child'))); ?></h1>

    <div class="panel panel-inverse" data-sortable-id="form-stuff-1">
        <!-- begin panel-heading -->
        <div class="panel-heading ui-sortable-handle">
            <h4 class="panel-title">Form</h4>
        </div>
        <form method="POST" action="<?php echo e(($action=='add')?'/dokumen':'/dokumen/'.$dokumen->id); ?>">
            <?php echo csrf_field(); ?>
            <?php if($action!='add'): ?>
            <?php echo method_field('PUT'); ?>
            <?php endif; ?>
            <div class="panel-body">
                <div class="row width-full">
                    <div class="col-md-2">
                        <div class="form-group">
                            <label class="control-label">Sumber</label>
                            <div class="input-group">
                                <select class="selectpicker show-tick form-control required" name="sumber_id" data-style="btn-warning" required>
                                    <option value="">Pilih Sumber</option>
                                    <?php $__currentLoopData = $data_sumber; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($dt->id); ?>" <?php echo e(old('sumber_id',$dokumen->sumber_id??'')==$dt->id ? 'selected' : ''); ?>><?php echo e($dt->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-1">
                        <div class="form-group">
                            <label class="control-label">JENIS</label>
                            <div class="input-group">
                                <select class="selectpicker show-tick form-control required" name="jenis" data-style="btn-primary" required>
                                    <option value="SIP">SIP</option>
                                    <option value="SIPA">SIPA</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label class="control-label">Nomor</label>
                            <div class="input-group">
                                <input type="text" placeholder="Nomor Dokumen" class="form-control" value="<?php echo e(($action!='add')?$dokumen->nomor:''); ?>" name="nomor">
                            </div>
                        </div>
                    </div>

                    <div class="col-md-2">
                        <div class="form-group">
                            <label class="control-label">Tanggal Berlaku</label>
                            <div class="input-group">
                                <input type="date" class="form-control" value="<?php echo e(old('tgl_berlaku',(isset($dokumen->tgl_berlaku) ? date('Y-m-d',strtotime($dokumen->tgl_berlaku)):''))); ?>" name="tgl_berlaku">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label class="control-label">Tanggal Berakhir</label>
                            <div class="input-group">
                                <input type="date" class="form-control" value="<?php echo e(old('tgl_berakhir',(isset($dokumen->tgl_berakhir) ? date('Y-m-d',strtotime($dokumen->tgl_berakhir)):''))); ?>" name="tgl_berakhir">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label class="control-label">Izin yg Diberikan (l/dt)</label>
                            <div class="input-group">
                                <input type="number" step="any" placeholder="Izin yang diberikan" class="form-control" value="<?php echo e(($action!='add')?$dokumen->izin:'0'); ?>" name="izin">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-7">
                        <div class="form-group">
                            <label class="control-label">Keterangan</label>
                            <div class="input-group">
                                <textarea class="form-control" name="ket" required><?php echo e(($action!='add')?$dokumen->ket:''); ?></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="panel-footer">
                <input type="submit" value="Simpan" class="btn btn-success m-r-3">
                <a wire:click="batal" class="btn btn-danger">Batal</a>
            </div>
    </div>

    </form>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins_scripts'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\sipro\resources\views/pages/dokumen/create.blade.php ENDPATH**/ ?>