<html lang="id">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=21cm, initial-scale=1">
    <meta name="description" content="Sistem Informasi Akademik Universitas Mataram">
    <meta name="author" content="Universitas Mataram">
    <title>LAPORAN PENGADAAN</title>
    <link rel="stylesheet" href="<?php echo e(asset('cetak/b.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('cetak/f.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('cetak/style.css')); ?>">

    <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('assets/img/logo.png')); ?>" sizes="16x16">
    <link rel="apple-touch-icon" href="<?php echo e(asset('assets/img/logo.png')); ?>">
    <link rel="apple-touch-icon-precomposed" href="<?php echo e(asset('assets/img/logo.png')); ?>">

    <style>
        @media  print {
            body {
                -webkit-print-color-adjust: exact;
            }
        }
    </style>
</head>

<body class="view mahasiswa halaman" onload="cetak()">
    <div class="container-fluid cetak krs">
        <div class="row">

            <center>
                <b style="font-size: 14px;">LAPORAN</b><br>
            </center>
            <br>
            <center>
                <table class="table table-hover table-bordered">
                    <tr>
                        <td style="text-align: center;" width="3%"><b>No.</b></td>
                        <td style="text-align: center;"><b>Nama Perusahaan</b></td>
                        <td style="text-align: center;"><b>Nama Pekerjaan</b></td>
                        <td style="text-align: center;"><b>Tgl Pekerjaan</b></td>
                        <td style="text-align: center;"><b>Pemberi Kerja</b></td>
                        <td style="text-align: center;"><b>Nilai</b></td>
                        <td style="text-align: center;"><b>Ongkos</b></td>
                        <td style="text-align: center;"><b>PPN</b></td>
                        <td style="text-align: center;"><b>PPH</b></td>
                        <td style="text-align: center;"><b>Internal</b></td>
                        <td style="text-align: center;"><b>Lainnya</b></td>
                        <td style="text-align: center;"><b>Sisa</b></td>
                    </tr>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $total=0;
                    ?>
                    <?php $__currentLoopData = $dt->ongkos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $total+=($x->jumlah*$x->harga);
                    ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <td style="text-align: center;" width="3%"><?php echo e($loop->iteration); ?></td>
                        <td style="text-align: center;"><?php echo e($dt->perusahaan->nama); ?></td>
                        <td style="text-align: center;"><?php echo e($dt->nama_pekerjaan); ?></td>
                        <td style="text-align: center;"><?php echo e(date('d-m-Y',strtotime($dt->tgl))); ?></td>
                        <td style="text-align: center;"><?php echo e($dt->pemberi_kerja); ?></td>
                        <td style="text-align: center;"><?php echo e(number_format($dt->nilai)); ?></td>

                        <td style="text-align: center;"><?php echo e(number_format($total)); ?></td>
                        <td style="text-align: center;"><?php echo e(number_format(($dt->ppn/100)*$dt->nilai)); ?></td>
                        <td style="text-align: center;"><?php echo e(number_format(($dt->pph/100)*$dt->nilai)); ?></td>
                        <td style="text-align: center;"><?php echo e(number_format(($dt->internal/100)*$dt->nilai)); ?></td>
                        <td style="text-align: center;"><?php echo e(number_format($dt->lainnya)); ?></td>
                        <td style="text-align: center;"><?php echo e(number_format($dt->nilai-($total+(($dt->ppn/100)*$dt->nilai)+(($dt->pph/100)*$dt->nilai)+(($dt->internal/100)*$dt->nilai)+($dt->lainnya)))); ?></td>
                    </tr>
                    <!-- <?php if(count($dt->ongkos)>0): ?>
                    <tr>
                        <td colspan="3">Daftar Realisai</td>
                        <td colspan="9" style="text-align: left;">
                            <?php $__currentLoopData = $dt->ongkos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            - <?php echo e($x->nama); ?> @ <?php echo e($x->jumlah); ?> (Rp. <?php echo e(number_format($x->harga)); ?> ) <br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    </tr>
                    <?php endif; ?> -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </table>
            </center>
        </div>
        <br>
    </div>

    <script type="text/javascript">
        function cetak() {
            window.print();
        };
    </script>


</body>

</html><?php /**PATH D:\laragon\www\pencatatan\resources\views/pages/laporan/cetak.blade.php ENDPATH**/ ?>