

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('plugins_styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="content" class="content">
    <!-- begin breadcrumb -->
    <ol class="breadcrumb pull-right">
        <li class="breadcrumb-item"><a href="<?php echo e(url('/dashboard')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item"><a>Data Master</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(url('/sumber')); ?>"><?php echo e(($action=='add')?$jenis:$sumber->jenis); ?></a></li>
        <li class="breadcrumb-item"><a>Tambah Data</a></li>
    </ol>
    <!-- end breadcrumb -->
    <!-- begin page-header -->
    <h1 class="page-header text-danger font-weight-bold"><span class="text-custom"><?php echo e(($action=='add')?'TAMBAH':'EDIT'); ?> DATA</span> <?php echo e(($action=='add')?$jenis:$sumber->jenis); ?></h1>


    <div class="panel panel-inverse" data-sortable-id="form-stuff-1">
        <!-- begin panel-heading -->
        <div class="panel-heading ui-sortable-handle">
            <h4 class="panel-title">Form Tambah Data</h4>
        </div>
        <form method="POST" action="<?php echo e(($action=='add')?'/sumber':'/sumber/'.$sumber->id); ?>">
            <?php echo csrf_field(); ?>
            <?php if($action!='add'): ?>
            <?php echo method_field('PUT'); ?>
            <?php endif; ?>
            <div class="panel-body">
                <div class="row width-full">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label class="control-label">Nama Sumber</label>
                            <div class="input-group">
                                <input type="text" class="form-control" style="display: block;" value="<?php echo e(old('nama',$sumber->nama??'')); ?>" name="nama" placeholder="Nama Sumber..." required>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-2">
                        <div class="form-group">
                            <label class="control-label">Jenis</label>
                            <div class="input-group">
                                <select class="selectpicker show-tick form-control required" name="jenis" data-style="btn-info" required>
                                    <option value="Mata Air" <?php echo e(old('jenis',$sumber->jenis??'')=='Sumber' ? 'selected' : ''); ?>>Mata Air</option>
                                    <option value="Sumur Bor" <?php echo e(old('jenis',$sumber->jenis??'')=='Sumur Bor' ? 'selected' : ''); ?>>Sumur Bor</option>
                                    <option value="Sungai" <?php echo e(old('jenis',$sumber->jenis??'')=='Sungai' ? 'selected' : ''); ?>>Sungai</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <!-- <div class="col-md-2">
                        <div class="form-group">
                            <label class="control-label">Alat Ukur</label>
                            <div class="input-group">
                                <select class="selectpicker show-tick form-control required" name="alat_ukur" data-style="btn-success" required>
                                    <option value="Water Meter Induk" <?php echo e(old('alat_ukur',$sumber->alat_ukur??'')=='Water Meter Induk' ? 'selected' : ''); ?>>Water Meter Induk</option>
                                </select>
                            </div>
                        </div>
                    </div> -->
                    <div class="col-md-3">
                        <div class="form-group">
                            <label class="control-label">Kecamatan</label>
                            <div class="input-group">
                                <select class="selectpicker show-tick form-control required" name="kecamatan" data-style="btn-primary" required>
                                    <option value="Ampenan" <?php echo e(old('kecamatan',$sumber->kecamatan??'')=='Ampenan' ? 'selected' : ''); ?>>Ampenan</option>
                                    <option value="Cakranegara" <?php echo e(old('kecamatan',$sumber->kecamatan??'')=='Cakranegara' ? 'selected' : ''); ?>>Cakranegara</option>
                                    <option value="Mataram" <?php echo e(old('kecamatan',$sumber->kecamatan??'')=='Mataram' ? 'selected' : ''); ?>>Mataram</option>
                                    <option value="Sandubaya" <?php echo e(old('kecamatan',$sumber->kecamatan??'')=='Sandubaya' ? 'selected' : ''); ?>>Sandubaya</option>
                                    <option value="Sekarbela" <?php echo e(old('kecamatan',$sumber->kecamatan??'')=='Sekarbela' ? 'selected' : ''); ?>>Sekarbela</option>
                                    <option value="Selaparang" <?php echo e(old('kecamatan',$sumber->kecamatan??'')=='Selaparang' ? 'selected' : ''); ?>>Selaparang</option>
                                    <option value="Gerung" <?php echo e(old('kecamatan',$sumber->kecamatan??'')=='Gerung' ? 'selected' : ''); ?>>Gerung</option>
                                    <option value="Kediri" <?php echo e(old('kecamatan',$sumber->kecamatan??'')=='Kediri' ? 'selected' : ''); ?>>Kediri</option>
                                    <option value="Narmada" <?php echo e(old('kecamatan',$sumber->kecamatan??'')=='Narmada' ? 'selected' : ''); ?>>Narmada</option>
                                    <option value="Sekotong" <?php echo e(old('kecamatan',$sumber->kecamatan??'')=='Sekotong' ? 'selected' : ''); ?>>Sekotong</option>
                                    <option value="Labu Api" <?php echo e(old('kecamatan',$sumber->kecamatan??'')=='Labu Api' ? 'selected' : ''); ?>>Labu Api</option>
                                    <option value="Gunung Sari" <?php echo e(old('kecamatan',$sumber->kecamatan??'')=='Gunung Sari' ? 'selected' : ''); ?>>Gunung Sari</option>
                                    <option value="Ligsar" <?php echo e(old('kecamatan',$sumber->kecamatan??'')=='Ligsar' ? 'selected' : ''); ?>>Ligsar</option>
                                    <option value="Lembar" <?php echo e(old('kecamatan',$sumber->kecamatan??'')=='Lembar' ? 'selected' : ''); ?>>Lembar</option>
                                    <option value="Batu Layar" <?php echo e(old('kecamatan',$sumber->kecamatan??'')=='Batu Layar' ? 'selected' : ''); ?>>Batu Layar</option>
                                    <option value="Kuripan" <?php echo e(old('kecamatan',$sumber->kecamatan??'')=='Kuripan' ? 'selected' : ''); ?>>Kuripan</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label class="control-label">Penjaga</label>
                            <div class="input-group">
                                <select class="selectpicker show-tick form-control" name="penjaga_id" data-style="btn-warning" required>
                                    <option value=''>Pilih Penjaga</option>
                                    <?php $__currentLoopData = $penjaga; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($dt->id); ?>" <?php echo e(old('penjaga_id',$sumber->penjaga_id??'')==$dt->id ? 'selected' : ''); ?>><?php echo e($dt->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label class="control-label">Kapasitas Liter/Detik</label>
                            <div class="input-group">
                                <input type="number" step="0.01" class="form-control" style="display: block;" value="<?php echo e(old('kapasitas_liter_perdetik',$sumber->kapasitas_liter_perdetik??'')); ?>" name="kapasitas_liter_perdetik" placeholder="Kapasitas Liter/Detik..." required>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label class="control-label">Kapasitas Meter Kubik</label>
                            <div class="input-group">
                                <input type="number" step="0.01" class="form-control" style="display: block;" value="<?php echo e(old('kapasitas_meter_kubik',$sumber->kapasitas_meter_kubik??'')); ?>" name="kapasitas_meter_kubik" placeholder="Kapasitas Meter Kubik..." required>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="panel-footer">
                <input type="submit" value="Simpan" class="btn btn-success m-r-3">
                <a wire:click="batal" class="btn btn-danger">Batal</a>
            </div>
    </div>

    </form>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins_scripts'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_scripts'); ?>
<script>

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\sipro\resources\views/pages/sumber/create.blade.php ENDPATH**/ ?>