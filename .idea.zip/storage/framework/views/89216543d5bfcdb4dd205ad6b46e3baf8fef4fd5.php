<html lang="id">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=21cm, initial-scale=1">
    <meta name="description" content="Sistem Informasi Akademik Universitas Mataram">
    <meta name="author" content="Universitas Mataram">
    <title>LAPORAN BACA WATER METER</title>
    <link rel="stylesheet" href="<?php echo e(asset('cetak/b.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('cetak/f.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('cetak/style.css')); ?>">

    <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('assets/img/logo.png')); ?>" sizes="16x16">
    <link rel="apple-touch-icon" href="<?php echo e(asset('assets/img/logo.png')); ?>">
    <link rel="apple-touch-icon-precomposed" href="<?php echo e(asset('assets/img/logo.png')); ?>">

    <style>

    </style>
</head>

<body class="view mahasiswa halaman" onload="cetak()">
    <div class="container-fluid cetak krs">
        <div class="row">

            <center>
                <b style="font-size: 14px;">PEMBACAAN ANGKA WATER METER INDUK</b><br>
            </center>
            <br>
            <table class="table table-hover table-bordered">

                <tBody>
                    <tr>
                        <td colspan="4" style="text-align: center;"> <b style="font-size: 13px;"><?php echo e($data[0]->sumber->nama); ?></b></td>
                    </tr>
                    <tr>
                        <td style="text-align: center;" width="20%"><b style=" font-size: 12px;">Tanggal</b></td>
                        <td style="text-align: center;"><b style="font-size: 12px;">Jam Baca</b></td>
                        <td style="text-align: center;"><b style="font-size: 12px;">Angka WM (<?php echo e($data[0]->jenis_wm->nama); ?>)</b></td>
                        <td style="text-align: center;"><b style="font-size: 12px;">Keterangan</b></td>
                    </tr>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <td style="text-align: center;"><?php echo e(date('d-m-Y', strtotime($dt->tgl))); ?></td>
                        <td style="text-align: center;"><?php echo e(substr($dt->jam_baca->jam,0,5)); ?></td>
                        <td style="text-align: center;"><?php echo e($dt->stan_ini); ?></td>
                        <td style="text-align: center;">-</td>
                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tBody>
            </table>
            <div class="pull-left ttd">
                QR-PRD/01-01
                <br> <br>Diperiksa<br>
                <br>Asisten Manajer & Reservoir & Perpompaan,
                <br><br>
                <?php echo '<img src="data:image/png;base64,' . DNS2D::getBarcodePNG('Diperiksa oleh : Asisten Manajer & Reservoir & Perpompaan', 'QRCODE', 1.5,1.5) . '" alt="barcode" />'; ?>

                <br><br>
                <span class="nama">Supriyanto</span>
            </div>


            <div class="pull-right ttd">
                <br> <br><?php echo e($data[0]->sumber->kecamatan); ?>, <?php echo e(\Carbon\Carbon::now()->translatedFormat('d F Y')); ?><br>
                <br>Pelaksana,
                <br><br>
                <?php echo '<img src="data:image/png;base64,' . DNS2D::getBarcodePNG('Diterbitkan oleh : '.Auth::user()->nama, 'QRCODE', 1.5,1.5) . '" alt="barcode" />'; ?>

                <br><br>
                <span class="nama"><?php echo e($data[0]->petugas); ?></span>
            </div>
        </div>
        <br>
    </div>

    <script type="text/javascript">
        function cetak() {
            window.print();
        };
    </script>


</body>

</html><?php /**PATH D:\laragon\www\sipro\resources\views/pages/riwayat/cetak.blade.php ENDPATH**/ ?>