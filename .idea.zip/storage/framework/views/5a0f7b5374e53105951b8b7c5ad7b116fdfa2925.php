

<?php $__env->startSection('title', 'Data Sumber'); ?>

<?php $__env->startSection('plugins_styles'); ?>
<link href="<?php echo e(asset('assets/vendors/dataTables/datatables.min.css')); ?>" rel="stylesheet" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="content" class="content">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header text-danger font-weight-bold"><span class="text-custom">DATA</span> SUMBER , SUMUR BOR, & SUNGAI</h1>
            <div class="panel panel-inverse " data-sortable-id="form-stuff-1">
                <!-- begin panel-heading -->
                <div class="panel-heading">
                    <div class="row width-full">
                        <div class="col-xl-3 col-sm-3">
                            <div class="form-inline">
                                <a href="<?php echo e(url('/sumber/create')); ?>" class="btn btn-primary"><i class="fa fa-plus"></i> Tambah Data</a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="panel-body table-responsive">
                    <table class="table table-hover data-table">
                        <thead>
                            <tr>
                                <th class="width-60">No.</th>
                                <th>NAMA</th>
                                <th>JENIS</th>
                                <th>KAPASITAS (liter/detik)</th>
                                <th>KAPASITAS (m<sup>3</sup>)</th>
                                <th>KECAMATAN</th>
                                <th>ALAT UKUR</th>
                                <th>PENJAGA</th>
                                <th class="width-90"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $sumber; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($loop->iteration); ?>

                                </td>
                                <td>
                                    <?php echo e($dt->nama); ?>

                                </td>
                                <td>
                                    <?php echo e($dt->jenis); ?>

                                </td>
                                <td>
                                    <?php echo e($dt->kapasitas_liter_perdetik); ?>

                                </td>
                                <td>
                                    <?php echo e($dt->kapasitas_meter_kubik); ?>

                                </td>
                                <td>
                                    <?php echo e($dt->kecamatan); ?>

                                </td>
                                <td>
                                    <?php echo e($dt->alat_ukur); ?>

                                </td>
                                <td>
                                    <?php echo e($dt->penjaga->nama??''); ?>

                                </td>
                                <td>
                                    <div class="btn-group btn-group-sm" role="group">
                                        <a href="/sumber/<?php echo e($dt->id); ?>/edit" class="btn btn-warning" style="font-size:12px; color:white;">Edit</a>
                                        <button id="" class="btn btn-white dropdown-toggle" data-toggle="dropdown"></button>
                                        <div class="dropdown-menu">
                                            <a href="/sumber/<?php echo e($dt->id); ?>" class="dropdown-item"> Detail</a>
                                            <a onclick="btnDelete('<?php echo e($dt->id); ?>')" class="dropdown-item"> Hapus</a>
                                        </div>
                                    </div>
                                </td>
                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
                <div class="panel-footer form-inline">
                    <div class="col-md-6 col-lg-10 col-xl-10 col-xs-12">
                        <div>
                        </div>
                    </div>
                </div>
            </div>
        </div>



    </div>


    <!-- end row -->
    <!-- begin row -->
    <!-- end row -->
    <!-- begin row -->
    <!-- end row -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins_scripts'); ?>
<script src="<?php echo e(asset('assets/vendors/dataTables/datatables.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_scripts'); ?>
<script>
    function btnDelete(kode) {
        Swal.fire({
            title: "Yakin?",
            text: "Anda akan menghapus data ini?",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yas, Hapus!"
        }).then(result => {
            if (result.value) {
                $.ajax({
                    url: "/sumber/" + kode,
                    type: "DELETE",
                    data: {
                        _token: "<?php echo e(csrf_token()); ?>"
                    },
                    success: function(response) {
                        Swal.fire(
                            "Deleted!",
                            "Data berhasil dihapus",
                            "success"
                        ).then(result => {
                            location.reload();
                        });
                        // You will get response from your PHP page (what you echo or print)
                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                        console.log(textStatus, errorThrown);
                    }
                });
            }
        });
    }
    $(function() {
        $(document).ready(function() {
            $('.data-table').DataTable({
                pageLength: 10,
                lengthChange: true,
                responsive: true,
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\sipro\resources\views/pages/sumber/index.blade.php ENDPATH**/ ?>