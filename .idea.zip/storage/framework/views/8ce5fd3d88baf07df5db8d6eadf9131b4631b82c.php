

<?php $__env->startSection('title', 'Barang'); ?>

<?php $__env->startSection('plugins_styles'); ?>
<link href="<?php echo e(asset('assets/vendors/dataTables/datatables.min.css')); ?>" rel="stylesheet" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="content" class="content">
    <!-- begin breadcrumb -->
    <ol class="breadcrumb pull-right">
        <li class="breadcrumb-item"><a href="<?php echo e(url('/dashboard')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="">Absen</a></li>
        <li class="breadcrumb-item"><a href="">TIDAK HADIRA</a></li>

    </ol>
    <!-- end breadcrumb -->
    <!-- begin page-header -->
    <h1 class="page-header text-danger font-weight-bold"><span class="text-custom">DATA</span> TIDAK HADIR</h1>
    <!-- end page-header -->
    <!-- begin row -->
    <div class="panel panel-inverse" data-sortable-id="form-stuff-1">
        <!-- begin panel-heading -->
        <div class="panel-heading">
            <div class="row width-full">
                <div class="col-lg-3">
                    <a href="<?php echo e(url('/tidak_hadir/create')); ?>" class="btn btn-primary"><i class="fa fa-plus"></i> Tambah</a>
                </div>
                <div class="col-lg-3">
                    <form action="/tidak_hadir/filter" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="input-group">
                            <input type="text" name="tgl" class="form-control" id="tgl_libur" placeholder="Pilih Tanggal">
                            <span class="input-group-append">
                                <span class="input-group-text"><i class="fa fa-calendar"></i></span>
                            </span>&nbsp;&nbsp;&nbsp;&nbsp;
                            <input type="submit" value="Filter" class="btn btn-green m-r-3">
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="panel-body table-responsive">
            <table class="table table-hover data-table">
                <thead>
                    <tr>
                        <th class="width-60">No.</th>
                        <th>No. Identitas</th>
                        <th>Nama</th>
                        <th>Waktu</th>
                        <th>Jenis</th>
                        <th>Keterangan</th>

                        <th class="width-90"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($dt->pegawai->no_identitas); ?></td>
                        <td><?php echo e($dt->pegawai->nama); ?></td>
                        <td><?php echo e(date('d-m-Y', strtotime($dt->tgl_mulai))); ?> s/d <?php echo e(date('d-m-Y', strtotime($dt->tgl_akhir))); ?></td>
                        <td><?php echo e($dt->jenis->jenis); ?></td>
                        <td><?php echo e($dt->ket); ?></td>
                        <td><a onclick="btnDelete('<?php echo e($dt->id); ?>')" class="btn btn-danger" style="font-size:12px; color:white;">Hapus</a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="panel-footer form-inline">
            <div class="col-md-6 col-lg-10 col-xl-10 col-xs-12">
                <div>
                </div>

            </div>

        </div>
    </div>
    <!-- end row -->
    <!-- begin row -->
    <!-- end row -->
    <!-- begin row -->
    <!-- end row -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins_scripts'); ?>
<script src="<?php echo e(asset('assets/vendors/dataTables/datatables.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_scripts'); ?>
<script>
    function btnDelete(kode) {
        Swal.fire({
            title: "Yakin?",
            text: "Anda akan menghapus data ini?",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yas, Hapus!"
        }).then(result => {
            if (result.value) {
                $.ajax({
                    url: "/tidak_hadir/" + kode,
                    type: "DELETE",
                    data: {
                        _token: "<?php echo e(csrf_token()); ?>"
                    },
                    success: function(response) {
                        Swal.fire(
                            "Deleted!",
                            "Data berhasil dihapus",
                            "success"
                        ).then(result => {
                            location.reload();
                        });
                        // You will get response from your PHP page (what you echo or print)
                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                        console.log(textStatus, errorThrown);
                    }
                });
            }
        });
    }
    $(function() {
        var date = new Date();
        var endDate = new Date("<?php echo e($endDate); ?>");
        var firstDate = new Date("<?php echo e($firstDate); ?>");
        $('#tgl_libur').val(("<?php echo e($tgl); ?>"));
        $('#tgl_libur').daterangepicker({
            startDate: firstDate, // after open picker you'll see this dates as picked
            endDate: endDate,
            autoUpdateInput: false,
            locale: {
                cancelLabel: 'Clear'
            }
        });

        $('#tgl_libur').on('apply.daterangepicker', function(ev, picker) {
            $(this).val(picker.startDate.format('DD-MM-YYYY') + ' s/d ' + picker.endDate.format('DD-MM-YYYY'));
            console.log(picker);
        });

        $('#tgl_libur').on('cancel.daterangepicker', function(ev, picker) {
            $(this).val('');
        });
        $(document).ready(function() {
            $('.data-table').DataTable({
                pageLength: 10,
                lengthChange: false,
                responsive: true,
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\inventariss\resources\views/pages/tidak_hadir/index.blade.php ENDPATH**/ ?>